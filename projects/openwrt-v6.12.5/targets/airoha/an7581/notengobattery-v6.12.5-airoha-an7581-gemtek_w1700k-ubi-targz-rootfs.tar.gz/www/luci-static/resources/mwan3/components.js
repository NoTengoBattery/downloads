'use strict';'require baseclass';var CARD_CLASS={success:'mwan3-card--ok',warning:'mwan3-card--warn',danger:'mwan3-card--bad',muted:'mwan3-card--muted',info:'mwan3-card--info',};var TEXT_CLASS={success:'mwan3-ok',warning:'mwan3-warn',danger:'mwan3-bad',muted:'mwan3-muted',info:'mwan3-info',};function cardClass(severity){return CARD_CLASS[severity]||CARD_CLASS.muted;}
function textClass(severity){return TEXT_CLASS[severity]||TEXT_CLASS.muted;}
function loadStyle(){var href=L.resource('view/mwan3/mwan3.css');var head=document.querySelector('head');if(head.querySelector('link[href="'+href+'"]'))
return;head.appendChild(E('link',{'rel':'stylesheet','type':'text/css','href':href}));}
function card(severity,children,extraClass){var cls='mwan3-card';if(severity)
cls+=' '+cardClass(severity);if(extraClass)
cls+=' '+extraClass;return E('div',{'class':cls},children);}
function summaryBar(severity,text){return E('div',{'class':'mwan3-summary '+cardClass(severity)+' '+textClass(severity)},[text]);}
function text(value){return document.createTextNode(value==null?'':''+value);}
function statusText(text,severity,bold){var cls=textClass(severity);if(bold)
cls+=' mwan3-strong';return E('span',{'class':cls},[text]);}
function badge(text){return E('span',{'class':'mwan3-badge'},[text]);}
function familyBadge(setType){return badge(setType==='ipv6_addr'?'IPv6':'IPv4');}
function mono(text){return E('span',{'class':'mwan3-mono'},[text]);}
function emptyHint(text){return E('em',{},[text]);}
function presenceBadge(present,expectation){if(expectation===true)
return present?statusText(_('Present'),'success',true):statusText(_('Missing'),'danger',true);if(expectation===false)
return present?statusText(_('Present (unexpected)'),'warning',true):statusText(_('Absent'),'muted',true);return present?statusText(_('Present'),'muted',true):statusText(_('Absent'),'muted',true);}
function statusInfo(d){switch(d.status){case'online':return{label:_('Online'),severity:'success',duration:d.online,durationLabel:_('Online')};case'offline':return{label:_('Offline'),severity:'danger',duration:d.offline,durationLabel:_('Offline')};case'notracking':return{label:_('No Tracking'),severity:d.uptime>0?'success':'warning',duration:d.uptime>0?d.uptime:null,durationLabel:_('Uptime')};default:return{label:_('Disabled'),severity:'muted',duration:null,durationLabel:null};}}
function kvRow(label,value){return E('tr',{'class':'mwan3-kv-row'},[E('td',{'class':'mwan3-kv-label'},label),E('td',{'class':'mwan3-kv-value'},value),]);}
function kvBlock(pairs){return E('table',{'class':'mwan3-kv'},pairs.map(function(p){return kvRow(p[0],p[1]);}));}
return baseclass.extend({loadStyle:loadStyle,textClass:textClass,text:text,card:card,summaryBar:summaryBar,statusText:statusText,statusInfo:statusInfo,badge:badge,familyBadge:familyBadge,mono:mono,emptyHint:emptyHint,presenceBadge:presenceBadge,kvRow:kvRow,kvBlock:kvBlock,});