'use strict';'require baseclass';'require uci';'require validation';function stub(){return{factory:validation,apply:function(type,value,args){if(value!=null)
this.value=value;return validation.types[type].apply(this,args);},assert:function(condition){return!!condition;}};}
function ipFamily(ip){if(!ip||ip.length===0)return null;var first=ip.split(',')[0].trim().split('/')[0];return validation.parseIPv6(first)?'ipv6':'ipv4';}
function ipAddrOrPrefix(value){var m=value.match(/^(\d+\.\d+\.\d+\.\d+)(?:\/(\d+\.\d+\.\d+\.\d+)|\/(\d{1,2}))?$/);if(m&&validation.parseIPv4(m[1])&&(m[2]?validation.parseIPv4(m[2]):(m[3]?+m[3]<=32:true)))
return true;m=value.match(/^([0-9a-fA-F:.]+)(?:\/(\d{1,3}))?$/);return!!(m&&validation.parseIPv6(m[1])&&(m[2]?+m[2]<=128:true));}
function ipv6Cidr(value,minPrefix,maxPrefix){var m=value.match(/^([0-9a-fA-F:.]+)\/(\d{1,3})$/);return!!(m&&validation.parseIPv6(m[1])&&+m[2]>=minPrefix&&+m[2]<=maxPrefix);}
function sectionNameInUse(value,exceptName){var sections=[...uci.sections('mwan3','interface'),...uci.sections('mwan3','member'),...uci.sections('mwan3','policy'),...uci.sections('mwan3','rule')];for(var j=0;j<sections.length;j++){if(exceptName!=null&&sections[j]['.name']===exceptName)
continue;if(sections[j]['.name']===value)
return true;}
return false;}
return baseclass.extend({stub:stub,ipFamily:ipFamily,ipAddrOrPrefix:ipAddrOrPrefix,ipv6Cidr:ipv6Cidr,sectionNameInUse:sectionNameInUse,});